declare module 'react-responsive-masonry' {
    import * as React from 'react';

    export interface ResponsiveMasonryProps {
        columnsCountBreakPoints?: Record<number, number>;
        children?: React.ReactNode;
    }

    export class ResponsiveMasonry extends React.Component<ResponsiveMasonryProps> { }

    export interface MasonryProps {
        gutter?: string;
        columnsCount?: number;
        children?: React.ReactNode;
        className?: string;
        style?: React.CSSProperties;
    }

    export default class Masonry extends React.Component<MasonryProps> { }
}
