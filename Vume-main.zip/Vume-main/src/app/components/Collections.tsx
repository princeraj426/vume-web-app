import { useState, useEffect } from 'react';
import { storage, Collection } from '../services/storage';
import { Media, searchMedia } from '../services/tmdb';
import { Trash2, Film, Clock, Heart, Plus, Search, ChevronRight, Bookmark } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { cn } from './ui/utils';

interface CollectionsProps {
    onMediaSelect: (media: Media) => void;
    onPlay: (media: Media) => void;
}

export function Collections({ onMediaSelect, onPlay }: CollectionsProps) {
    const [activeTab, setActiveTab] = useState<'watchlist' | 'history' | 'custom'>('watchlist');
    const [items, setItems] = useState<Media[]>([]);
    const [collections, setCollections] = useState<Collection[]>([]);
    const [selectedCollection, setSelectedCollection] = useState<Collection | null>(null);
    const [isSearching, setIsSearching] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<Media[]>([]);

    useEffect(() => {
        refreshData();
    }, [activeTab, selectedCollection]);

    const refreshData = () => {
        setCollections(storage.getCollections());
        if (activeTab === 'watchlist') {
            setItems(storage.getWatchlist());
        } else if (activeTab === 'history') {
            setItems(storage.getHistory());
        } else if (selectedCollection) {
            const cols = storage.getCollections();
            const current = cols.find(c => c.id === selectedCollection.id);
            setItems(current?.items || []);
        }
    };

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) return;
        setIsSearching(true);
        try {
            const results = await searchMedia(searchQuery);
            setSearchResults(results.results);
        } catch (error) {
            console.error('Search error:', error);
        } finally {
            setIsSearching(false);
        }
    };

    const addToCurrentCollection = (media: Media) => {
        if (!selectedCollection) return;
        storage.addToCollection(selectedCollection.id, media);
        setSearchQuery('');
        setSearchResults([]);
        refreshData();
    };

    const removeFromCurrent = (media: Media) => {
        if (activeTab === 'watchlist') {
            storage.toggleWatchlist(media);
        } else if (selectedCollection) {
            storage.removeFromCollection(selectedCollection.id, media.tmdbId, media.type);
        }
        refreshData();
    };

    return (
        <div className="flex-1 space-y-12 animate-in fade-in duration-700">
            {/* Bento Navigation for Collections */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <button
                    onClick={() => { setActiveTab('watchlist'); setSelectedCollection(null); }}
                    className={cn(
                        "p-8 rounded-[32px] flex flex-col items-center justify-center gap-4 transition-all duration-500 border grainy",
                        activeTab === 'watchlist' ? "bg-[#d95f47] border-[#d95f47] text-white shadow-2xl shadow-[#d95f47]/20" : "bg-[#2a2420] border-white/5 text-gray-500 hover:border-white/20"
                    )}
                >
                    <Heart className={cn("w-10 h-10", activeTab === 'watchlist' && "fill-white")} />
                    <span className="text-xs font-black uppercase tracking-[0.2em]">Watchlist</span>
                </button>
                <button
                    onClick={() => { setActiveTab('history'); setSelectedCollection(null); }}
                    className={cn(
                        "p-8 rounded-[32px] flex flex-col items-center justify-center gap-4 transition-all duration-500 border grainy",
                        activeTab === 'history' ? "bg-[#f5f1ed] border-white text-[#1a1410] shadow-2xl shadow-white/10" : "bg-[#2a2420] border-white/5 text-gray-500 hover:border-white/20"
                    )}
                >
                    <Clock className="w-10 h-10" />
                    <span className="text-xs font-black uppercase tracking-[0.2em]">History</span>
                </button>
                <div className="col-span-2 p-8 rounded-[32px] bg-[#2a2420] border border-white/5 grainy flex flex-col gap-4">
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#d95f47]">Custom Collections</span>
                    <div className="flex gap-2 overflow-x-auto no-scrollbar">
                        {collections.map(col => (
                            <button
                                key={col.id}
                                onClick={() => { setActiveTab('custom'); setSelectedCollection(col); }}
                                className={cn(
                                    "px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border shrink-0",
                                    selectedCollection?.id === col.id ? "bg-white text-[#1a1410] border-white" : "bg-white/5 border-white/5 text-gray-400 hover:text-white"
                                )}
                            >
                                {col.name}
                            </button>
                        ))}
                        {collections.length === 0 && <p className="text-[10px] text-white/20 uppercase tracking-widest py-3">No custom collections yet</p>}
                    </div>
                </div>
            </div>

            {/* Collection Content */}
            <div className="space-y-8">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-4xl font-black tracking-tighter uppercase">
                            {activeTab === 'watchlist' ? 'Watchlist' : activeTab === 'history' ? 'History' : selectedCollection?.name}
                        </h2>
                        <p className="text-gray-500 text-sm mt-1 uppercase tracking-widest font-bold">
                            {items.length} {items.length === 1 ? 'Item' : 'Items'} in this list
                        </p>
                    </div>

                    {activeTab === 'custom' && selectedCollection && (
                        <div className="flex gap-4">
                            <button
                                onClick={() => { storage.deleteCollection(selectedCollection.id); setActiveTab('watchlist'); setSelectedCollection(null); }}
                                className="p-4 rounded-2xl bg-white/5 hover:bg-red-500/20 text-gray-500 hover:text-red-500 border border-white/5 transition-all"
                            >
                                <Trash2 className="w-5 h-5" />
                            </button>
                        </div>
                    )}
                </div>

                {/* Add to collection search (for custom collections) */}
                {activeTab === 'custom' && selectedCollection && (
                    <div className="p-8 rounded-[40px] bg-white/5 border border-white/5 grainy">
                        <form onSubmit={handleSearch} className="flex gap-4">
                            <div className="relative flex-1">
                                <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                <input
                                    type="text"
                                    placeholder="Search movies or shows to add..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="w-full bg-[#1a1410] border border-white/10 rounded-2xl pl-16 pr-6 py-4 focus:outline-none focus:ring-2 focus:ring-[#d95f47] transition-all"
                                />
                            </div>
                            <button
                                type="submit"
                                disabled={isSearching}
                                className="px-8 py-4 rounded-2xl bg-[#d95f47] font-black uppercase tracking-widest text-xs hover:bg-[#c54f37] transition-all disabled:opacity-50"
                            >
                                {isSearching ? 'Searching...' : 'Search'}
                            </button>
                        </form>

                        {searchResults.length > 0 && (
                            <div className="mt-8 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 animate-in slide-in-from-top-4 duration-500">
                                {searchResults.map(m => (
                                    <div key={m.tmdbId} className="group relative aspect-[2/3] rounded-2xl overflow-hidden grainy border border-white/10">
                                        <ImageWithFallback src={m.posterImage} className="w-full h-full object-cover" />
                                        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-4 text-center opacity-0 group-hover:opacity-100 transition-opacity">
                                            <p className="text-xs font-bold mb-4 line-clamp-2">{m.title}</p>
                                            <button
                                                onClick={() => addToCurrentCollection(m)}
                                                className="w-10 h-10 rounded-full bg-[#d95f47] flex items-center justify-center hover:scale-110 transition-transform"
                                            >
                                                <Plus className="w-5 h-5" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Items Grid */}
                {items.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                        {items.map((item) => (
                            <div key={`${item.type}_${item.tmdbId}`} className="group space-y-3">
                                <div
                                    onClick={() => onMediaSelect(item)}
                                    className="relative aspect-[2/3] rounded-[32px] overflow-hidden grainy border border-white/5 cursor-pointer shadow-xl shadow-black/20 hover:shadow-black/40 transition-all hover:scale-[1.02]"
                                >
                                    <ImageWithFallback src={item.posterImage} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />

                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                        <button
                                            onClick={(e) => { e.stopPropagation(); onPlay(item); }}
                                            className="w-12 h-12 rounded-full bg-[#d95f47] flex items-center justify-center hover:scale-110 transition-transform"
                                        >
                                            <Bookmark className="w-5 h-5 fill-white" />
                                        </button>
                                        <button
                                            onClick={(e) => { e.stopPropagation(); removeFromCurrent(item); }}
                                            className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                                        >
                                            <Trash2 className="w-5 h-5 text-white" />
                                        </button>
                                    </div>
                                </div>
                                <div onClick={() => onMediaSelect(item)} className="cursor-pointer">
                                    <h3 className="font-bold text-sm tracking-tight truncate group-hover:text-[#d95f47] transition-colors">{item.title}</h3>
                                    <p className="text-[10px] text-gray-500 uppercase tracking-widest font-medium mt-1">
                                        {item.type === 'movie' ? item.duration : 'TV Series'}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="h-96 rounded-[40px] border border-dashed border-white/10 flex flex-col items-center justify-center text-gray-500 gap-6">
                        <Film className="w-16 h-16 opacity-10" />
                        <div className="text-center">
                            <p className="font-black uppercase tracking-[0.2em] text-xs">This collection is empty</p>
                            <p className="text-sm font-light mt-2">Start adding your favorite titles here.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
