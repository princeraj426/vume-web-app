import { useEffect } from 'react';

interface MediaProps {
    id: number;
    type: 'movie' | 'tv';
    title: string;
    posterImage: string;
    backdropImage: string;
    currentSeason?: number;
    currentEpisode?: number;
}

interface PlayerProps {
    movie: MediaProps;
}

export function Player({ movie }: PlayerProps) {
    const season = movie.currentSeason || 1;
    const episode = movie.currentEpisode || 1;

    // Reverting to VidFast as the primary reliable provider for the user.
    // It requires no sandbox and we will use the blur event to somewhat mitigate popups.
    const embedUrl = movie.type === 'movie'
        ? `https://vidfast.pro/movie/${movie.id}`
        : `https://vidfast.pro/tv/${movie.id}/${season}/${episode}`;

    // Aggressively attempt to yank focus back to the app if an ad steals window focus.
    useEffect(() => {
        const handleBlur = () => {
            setTimeout(() => {
                window.focus();
            }, 100);
        };
        window.addEventListener('blur', handleBlur);
        return () => window.removeEventListener('blur', handleBlur);
    }, []);

    return (
        <div className="w-full h-full bg-black relative">
            <iframe
                src={embedUrl}
                className="w-full h-full border-0"
                allowFullScreen
            // We cannot use a strict sandbox. All major free providers now 
            // run scripts to detect it and block playback. We rely on the 
            // onBlur focus-hijacking script above to mitigate bad UX.
            />
        </div>
    );
}
