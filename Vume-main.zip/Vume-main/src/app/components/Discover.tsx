import { useState, useEffect, useRef, useCallback } from 'react';
import Masonry, { ResponsiveMasonry } from 'react-responsive-masonry';
import { Loader2, Play, Star, Sparkles, Quote, Trophy } from 'lucide-react';
import { Media, getDiscoverMedia, searchMedia, getGenres } from '../services/tmdb';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { cn } from './ui/utils';

interface DiscoverProps {
  onMediaSelect: (media: Media) => void;
  searchQuery: string;
}

const cache: Record<string, { results: Media[]; totalPages: number; lastPage: number }> = {};

export default function Discover({ onMediaSelect, searchQuery }: DiscoverProps) {
  const [items, setItems] = useState<Media[]>([]);
  const [genres, setGenres] = useState<{ id: number; name: string }[]>([]);
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null);
  const [type, setType] = useState<'movie' | 'tv'>('movie');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [randomGenre, setRandomGenre] = useState<any>(null);
  const [randomReviews, setRandomReviews] = useState<any[]>([]);
  const [topList, setTopList] = useState<Media[]>([]);
  const [showFullTopList, setShowFullTopList] = useState(false);
  const [rouletteMedia, setRouletteMedia] = useState<Media | null>(null);
  const [hiddenGem, setHiddenGem] = useState<Media | null>(null);
  const observerTarget = useRef<HTMLDivElement>(null);

  const cacheKey = searchQuery ? `search_${searchQuery}` : `${type}_genre_${selectedGenre || 'all'}`;

  useEffect(() => {
    getGenres(type).then(setGenres);
  }, [type]);

  const fetchMedia = useCallback(async (pageNum: number, isNewSearch: boolean = false) => {
    if (loading) return;

    if (isNewSearch && cache[cacheKey]) {
      setItems(cache[cacheKey].results);
      setTotalPages(cache[cacheKey].totalPages);
      setPage(cache[cacheKey].lastPage);
      return;
    }

    setLoading(true);
    try {
      const response = searchQuery
        ? await searchMedia(searchQuery, pageNum)
        : await getDiscoverMedia(type, pageNum, selectedGenre?.toString());

      if (response) {
        setItems((prev: Media[]) => {
          const newItems = isNewSearch ? response.results : [...prev, ...response.results];
          const uniqueItems = Array.from(new Map(newItems.map((m: Media) => [`${m.type}_${m.tmdbId}`, m])).values());

          cache[cacheKey] = {
            results: uniqueItems,
            totalPages: response.totalPages,
            lastPage: pageNum
          };

          return uniqueItems;
        });
        setTotalPages(response.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch media:', error);
    } finally {
      setLoading(false);
    }
  }, [searchQuery, selectedGenre, type, cacheKey, loading]);

  useEffect(() => {
    if (items.length > 0 && genres.length > 0) {
      const g = genres[Math.floor(Math.random() * genres.length)];
      setRandomGenre(g);

      const quotes = [
        "An absolute visual triumph that demands to be seen on the biggest screen possible.",
        "A breathtaking masterpiece that redefines its genre from the ground up.",
        "Emotionally resonant, visually stunning, and entirely unforgettable.",
        "A gripping narrative that keeps you guessing until the very last frame.",
        "A profound cinematic experience that will stay with you long after the credits roll."
      ];

      const reviews = [];
      for (let i = 0; i < 5; i++) {
        const item = items[Math.floor(Math.random() * items.length)];
        if (item) {
          reviews.push({
            media: item,
            quote: quotes[i % quotes.length],
            source: "VUME CRITICS"
          });
        }
      }
      setRandomReviews(reviews);

      setTopList(items.slice(0, 10));

      // Select Roulette
      const highRated = items.filter(m => Number(m.rating || 0) > 7.5);
      if (highRated.length > 0) {
        setRouletteMedia(highRated[Math.floor(Math.random() * highRated.length)]);
      }

      // Select Hidden Gem (simulated by taking something further down the list with good rating)
      if (items.length > 10) {
        const potentialGems = items.slice(10).filter(m => Number(m.rating || 0) > 7.0);
        if (potentialGems.length > 0) {
          setHiddenGem(potentialGems[Math.floor(Math.random() * potentialGems.length)]);
        }
      }
    }
  }, [items.length > 0, genres.length > 0]);

  useEffect(() => {
    setItems([]);
    setPage(1);
    fetchMedia(1, true);
  }, [searchQuery, selectedGenre, type]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries: IntersectionObserverEntry[]) => {
        if (entries[0].isIntersecting && page < totalPages && !loading) {
          const nextPage = page + 1;
          setPage(nextPage);
          fetchMedia(nextPage);
        }
      },
      { threshold: 0.1 }
    );

    if (observerTarget.current) {
      observer.observe(observerTarget.current);
    }

    return () => {
      if (observerTarget.current) {
        observer.unobserve(observerTarget.current);
      }
    };
  }, [page, totalPages, loading, fetchMedia]);

  const renderSpecialCard = (index: number) => {
    if (index === 2 && randomGenre) {
      return (
        <div
          key="special-1"
          onClick={() => setSelectedGenre(randomGenre.id)}
          className="bg-[var(--accent-color)] rounded-[32px] md:rounded-[40px] p-8 md:p-10 flex flex-col justify-between min-h-[300px] md:min-h-[400px] grainy cursor-pointer hover:scale-[1.02] transition-all group"
        >
          <div>
            <Sparkles className="w-8 h-8 md:w-10 md:h-10 mb-6 md:mb-8 text-white/80 group-hover:rotate-12 transition-transform" />
            <h3 className="text-3xl md:text-4xl font-black mb-4 md:mb-6 tracking-tighter leading-none">{randomGenre.name} & Beyond</h3>
            <p className="text-white/80 font-light text-sm md:text-lg">Dive deep into our curated {randomGenre.name.toLowerCase()} collections.</p>
          </div>
          <button className="flex items-center gap-2 md:gap-3 text-[10px] md:text-xs font-black bg-white/10 hover:bg-white/20 px-6 py-3 md:px-8 md:py-4 rounded-full transition-all w-fit uppercase tracking-widest border border-white/5 mt-4">
            Explore Collection <Play className="w-3 h-3 md:w-4 md:h-4 fill-white" />
          </button>
        </div>
      );
    }

    if (index === 4 && rouletteMedia) {
      return (
        <div
          key="special-roulette"
          onClick={() => onMediaSelect(rouletteMedia)}
          className="bg-gradient-to-br from-indigo-900 via-purple-900 to-black rounded-[32px] md:rounded-[40px] p-8 md:p-10 flex flex-col justify-between min-h-[350px] md:min-h-[450px] cursor-pointer hover:scale-[1.02] transition-all group relative overflow-hidden border border-white/10"
        >
          <div className="absolute inset-0 opacity-20 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] mix-blend-overlay"></div>
          <div className="absolute -right-20 -top-20 w-64 h-64 bg-rose-500/20 rounded-full blur-[80px]"></div>

          <div className="relative z-10 flex-1 flex flex-col items-center justify-center text-center gap-6">
            <div className="bg-white/10 p-5 rounded-full backdrop-blur-md group-hover:scale-110 transition-transform duration-500 mb-2 border border-white/10">
              <Play className="w-8 h-8 md:w-12 md:h-12 fill-white text-white ml-1" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-rose-400 mb-4 block">Feeling Lucky?</span>
              <h3 className="text-4xl md:text-5xl font-black tracking-tighter leading-none text-white drop-shadow-lg">Watch<br />Roulette</h3>
            </div>
          </div>
        </div>
      );
    }
    if (index > 0 && index % 9 === 4 && randomReviews.length > 0) {
      const reviewIndex = Math.floor(index / 9) % randomReviews.length;
      const review = randomReviews[reviewIndex];
      return (
        <div
          key={`special-review-${index}`}
          onClick={() => onMediaSelect(review.media)}
          className="bg-[#2a2420] border border-white/5 rounded-[32px] md:rounded-[40px] p-6 md:p-10 flex flex-col justify-center gap-6 md:gap-8 grainy min-h-[300px] md:min-h-[450px] cursor-pointer hover:border-[var(--accent-color)]/50 transition-all"
        >
          <Quote className="w-8 h-8 md:w-12 md:h-12 text-[var(--accent-color)] opacity-30" />
          <p className="text-xl md:text-3xl font-light italic leading-tight text-white/95 tracking-tight">
            "{review.quote}"
          </p>
          <div className="flex items-center gap-4 md:gap-5">
            <ImageWithFallback src={review.media.posterImage} className="w-10 h-14 md:w-14 md:h-20 rounded-xl object-cover shadow-xl" />
            <div className="min-w-0 flex-1">
              <p className="font-black text-[10px] md:text-xs tracking-[0.2em] uppercase text-[var(--accent-color)] truncate">{review.source}</p>
              <p className="text-xs md:text-sm text-gray-400 mt-1 uppercase font-bold tracking-tighter truncate">Review for {review.media.title}</p>
            </div>
          </div>
        </div>
      );
    }
    if (index === 8 && topList.length > 0) {
      const displayList = showFullTopList ? topList : topList.slice(0, 5);
      return (
        <div key="special-3" className="bg-[#f5f1ed] rounded-[32px] md:rounded-[40px] p-8 md:p-10 flex flex-col justify-between grainy min-h-[400px] md:min-h-[500px] text-[#1a1410]">
          <div>
            <div className="flex items-center gap-3 mb-8 md:mb-10">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-xl md:rounded-2xl bg-[var(--accent-color)] flex items-center justify-center">
                <Trophy className="w-4 h-4 md:w-6 md:h-6 text-white" />
              </div>
              <div>
                <span className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-[var(--accent-color)]">Hand-picked</span>
                <h3 className="text-xl md:text-2xl font-black tracking-tighter uppercase leading-none">Weekly Top 10</h3>
              </div>
            </div>
            <div className="space-y-3 md:space-y-4">
              {displayList.map((m, i) => (
                <div
                  key={m.tmdbId}
                  onClick={() => onMediaSelect(m)}
                  className="flex items-center justify-between group cursor-pointer border-b border-black/5 pb-2 md:pb-3 hover:border-black/20 transition-all font-bold"
                >
                  <span className="text-sm md:text-base tracking-tight group-hover:text-[var(--accent-color)] transition-colors line-clamp-1">{m.title}</span>
                  <span className="text-[10px] font-black text-gray-400">{(i + 1).toString().padStart(2, '0')}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-3 mt-6">
            <button
              onClick={(e) => { e.stopPropagation(); setShowFullTopList(!showFullTopList); }}
              className="text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-[#1a1410] transition-colors w-fit mx-auto"
            >
              {showFullTopList ? "Show Less" : "View Full Top 10"}
            </button>
            <button
              onClick={() => setType(type === 'movie' ? 'tv' : 'movie')}
              className="bg-[#1a1410] text-white px-6 py-3 md:px-8 md:py-4 rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-widest hover:bg-[var(--accent-color)] transition-all shadow-xl shadow-black/10 w-full"
            >
              Switch to {type === 'movie' ? 'TV' : 'Movies'}
            </button>
          </div>
        </div>
      );
    }

    if (index === 15 && hiddenGem) {
      return (
        <div
          key="special-gem"
          onClick={() => onMediaSelect(hiddenGem)}
          className="bg-[#1a1410] border-2 border-dashed border-white/20 rounded-[32px] md:rounded-[40px] p-8 md:p-10 flex flex-col justify-between min-h-[300px] md:min-h-[400px] cursor-pointer hover:border-[var(--accent-color)] transition-all group"
        >
          <div className="flex flex-col gap-6">
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-cyan-400 px-3 py-1 bg-cyan-400/10 rounded-md border border-cyan-400/20">Hidden Gem</span>
              <Star className="w-6 h-6 text-yellow-500 fill-yellow-500 group-hover:rotate-45 transition-transform duration-500" />
            </div>
            <p className="text-2xl md:text-4xl font-light leading-tight text-white/95">
              A highly rated masterpiece you <span className="font-bold italic text-[var(--accent-color)]">probably missed.</span>
            </p>
          </div>

          <div className="flex items-center gap-4 mt-8">
            <ImageWithFallback src={hiddenGem.posterImage} className="w-12 h-16 md:w-16 md:h-20 rounded-lg object-cover shadow-xl opacity-80 group-hover:opacity-100 transition-opacity" />
            <div className="min-w-0">
              <h3 className="font-black text-sm md:text-lg uppercase tracking-tight truncate line-clamp-1">{hiddenGem.title}</h3>
              <div className="flex items-center gap-2 text-[10px] font-bold text-gray-500 uppercase mt-1">
                <span>{hiddenGem.rating} Score</span>
                <span>•</span>
                <span>Discover Now</span>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar bg-[#1a1410]">
      <div className="mb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-12">
          <h2 className="text-6xl font-black tracking-tighter uppercase">
            {searchQuery ? 'Search' : 'Discover'}
          </h2>
          {!searchQuery && (
            <div className="flex bg-[#2a2420] p-1.5 rounded-2xl border border-white/5 grainy shadow-2xl">
              <button
                onClick={() => setType('movie')}
                className={cn(
                  "px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                  type === 'movie' ? "bg-[var(--accent-color)] text-white shadow-xl" : "text-gray-500 hover:text-white"
                )}
              >
                Films
              </button>
              <button
                onClick={() => setType('tv')}
                className={cn(
                  "px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                  type === 'tv' ? "bg-[var(--accent-color)] text-white shadow-xl" : "text-gray-500 hover:text-white"
                )}
              >
                Series
              </button>
            </div>
          )}
        </div>

        {!searchQuery && (
          <div className="flex gap-3 overflow-x-auto pb-6 no-scrollbar">
            <button
              onClick={() => setSelectedGenre(null)}
              className={cn(
                "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border shrink-0",
                selectedGenre === null ? "bg-white text-[#1a1410] border-white shadow-xl shadow-white/5" : "bg-white/5 border-white/5 text-gray-500 hover:text-white"
              )}
            >
              All Genres
            </button>
            {genres.map((genre: { id: number; name: string }) => (
              <button
                key={genre.id}
                onClick={() => setSelectedGenre(genre.id)}
                className={cn(
                  "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border shrink-0",
                  selectedGenre === genre.id ? "bg-[var(--accent-color)] border-[var(--accent-color)] text-white shadow-lg shadow-[var(--accent-color)]/20" : "bg-white/5 border-white/5 text-gray-500 hover:text-white"
                )}
              >
                {genre.name}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="columns-2 sm:columns-3 lg:columns-4 xl:columns-5 gap-4">
        {items.flatMap((item: Media, index: number) => {
          const elements = [];

          const special = renderSpecialCard(index);
          if (special) {
            elements.push(
              <div key={`wrap-special-${index}`} className="break-inside-avoid mb-4 inline-block w-full">
                {special}
              </div>
            );
          }

          // Scatter landscape items based on their unique ID to organically distribute them
          // across all masonry columns and prevent the pooling bug.
          const isLandscape = item.backdropImage && (item.tmdbId % 6 === 0 || item.tmdbId % 11 === 0);

          elements.push(
            <div key={`wrap-item-${item.tmdbId}`} className="break-inside-avoid mb-4 inline-block w-full">
              <div
                className={cn(
                  "group relative bg-[#2a2420] rounded-[32px] md:rounded-[40px] overflow-hidden cursor-pointer transition-all duration-700 hover:scale-[1.03] hover:shadow-2xl hover:shadow-black grainy",
                  isLandscape ? "aspect-video" : "aspect-[2/3]"
                )}
                onClick={() => onMediaSelect(item)}
              >
                <ImageWithFallback
                  src={isLandscape ? item.backdropImage : item.posterImage}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                />

                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity p-4 md:p-8 flex flex-col justify-end">
                  <div className="flex items-center gap-4 mb-2 md:mb-4">
                    <div className="bg-[var(--accent-color)] p-2 md:p-4 rounded-xl md:rounded-2xl scale-0 group-hover:scale-100 transition-transform duration-500 shadow-xl shadow-[var(--accent-color)]/20">
                      <Play className="w-3 h-3 md:w-5 md:h-5 fill-white text-white ml-0.5" />
                    </div>
                    <span className="hidden md:inline text-[10px] font-black tracking-[0.2em] uppercase text-white/80">View Details</span>
                  </div>
                  <h3 className="text-lg md:text-2xl font-black mb-1 md:mb-3 tracking-tighter uppercase leading-none line-clamp-2 md:line-clamp-none">{item.title}</h3>
                  <div className="flex items-center gap-2 md:gap-6 text-[8px] md:text-[10px] font-black text-white/50 uppercase tracking-widest">
                    <span className="flex items-center gap-1 md:gap-2">
                      <Star className="w-3 h-3 md:w-3.5 md:h-3.5 text-yellow-500 fill-yellow-500" />
                      {item.rating}
                    </span>
                    <span className="hidden md:inline">{item.type === 'movie' ? item.duration : 'TV Series'}</span>
                  </div>
                </div>
              </div>
            </div>
          );

          return elements;
        })}
      </div>

      <div ref={observerTarget} className="w-full py-40 flex items-center justify-center">
        {loading && <Loader2 className="w-12 h-12 text-[var(--accent-color)] animate-spin" />}
      </div>
    </div>
  );
}
