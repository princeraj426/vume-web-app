const BASE_URL = 'https://peak-unemployed-activitis.ramanrewatiboss.workers.dev/3';
const IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';

export interface TMDBMedia {
  id: number;
  title?: string;
  name?: string;
  overview: string;
  poster_path: string;
  backdrop_path: string;
  vote_average: number;
  release_date?: string;
  first_air_date?: string;
  popularity: number;
  runtime?: number;
  episode_run_time?: number[];
  number_of_seasons?: number;
  number_of_episodes?: number;
  genres?: { id: number; name: string }[];
  credits?: {
    cast: { id: number; name: string; profile_path: string | null }[];
    crew: { id: number; name: string; job: string; profile_path: string | null }[];
  };
  release_dates?: {
    results: {
      iso_3166_1: string;
      release_dates: { certification: string }[];
    }[];
  };
  content_ratings?: {
    results: {
      iso_3166_1: string;
      rating: string;
    }[];
  };
}

export interface Media {
  id: number;
  tmdbId: number;
  title: string;
  type: 'movie' | 'tv';
  duration: string;
  rating: string;
  ageRating: string;
  description: string;
  cast: { id: number; name: string; profilePath: string | null }[];
  popularity: string;
  director: { id: number; name: string; profilePath: string | null };
  directorImage: string;
  posterImage: string;
  backdropImage: string;
  trailerTime: string;
  year: string;
  seasons?: number;
  episodes?: number;
  currentSeason?: number;
  currentEpisode?: number;
}

const getHeaders = () => ({
  'Content-Type': 'application/json',
  'Accept': 'application/json',
});

const apiCache = new Map<string, any>();

const fetchTMDB = async (endpoint: string, params: Record<string, string> = {}) => {
  const cacheKey = `${endpoint}?${new URLSearchParams(params).toString()}`;
  if (apiCache.has(cacheKey)) {
    return apiCache.get(cacheKey);
  }

  const queryParams = new URLSearchParams(params);

  const response = await fetch(`${BASE_URL}${endpoint}?${queryParams}`, {
    headers: getHeaders(),
  });

  if (!response.ok) {
    throw new Error(`TMDB API error: ${response.statusText}`);
  }

  const data = await response.json();
  apiCache.set(cacheKey, data);
  return data;
};

export const getImageUrl = (path: string | null, size: string = 'w500') => {
  if (!path) return 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=2070&auto=format&fit=crop';
  return `${IMAGE_BASE_URL}/${size}${path}`;
};

const mapTMDBMediaToMedia = (tmdbMedia: TMDBMedia, type: 'movie' | 'tv'): Media => {
  const director = tmdbMedia.credits?.crew.find((member) =>
    type === 'movie' ? member.job === 'Director' : member.job === 'Executive Producer'
  );

  let ageRating = 'N/A';
  if (type === 'movie') {
    const releaseDates = tmdbMedia.release_dates?.results.find(r => r.iso_3166_1 === 'US') || tmdbMedia.release_dates?.results[0];
    ageRating = releaseDates?.release_dates[0]?.certification || 'N/A';
  } else {
    const contentRatings = tmdbMedia.content_ratings?.results.find(r => r.iso_3166_1 === 'US') || tmdbMedia.content_ratings?.results[0];
    ageRating = contentRatings?.rating || 'N/A';
  }

  let duration = 'N/A';
  if (type === 'movie') {
    duration = tmdbMedia.runtime ? `${Math.floor(tmdbMedia.runtime / 60)}h ${tmdbMedia.runtime % 60}m` : 'N/A';
  } else {
    duration = tmdbMedia.episode_run_time?.[0] ? `${tmdbMedia.episode_run_time[0]}m` : 'N/A';
  }

  return {
    id: tmdbMedia.id,
    tmdbId: tmdbMedia.id,
    title: tmdbMedia.title || tmdbMedia.name || 'Unknown',
    type,
    duration,
    rating: tmdbMedia.vote_average.toFixed(1),
    ageRating,
    description: tmdbMedia.overview,
    cast: tmdbMedia.credits?.cast.slice(0, 5).map(c => ({
      id: c.id,
      name: c.name,
      profilePath: getImageUrl(c.profile_path, 'w185')
    })) || [],
    popularity: Math.round(tmdbMedia.popularity).toLocaleString(),
    director: {
      id: director?.id || 0,
      name: director?.name || 'Unknown',
      profilePath: getImageUrl(director?.profile_path || null, 'w185')
    },
    directorImage: getImageUrl(director?.profile_path || null, 'w185'),
    posterImage: getImageUrl(tmdbMedia.poster_path, 'w780'),
    backdropImage: getImageUrl(tmdbMedia.backdrop_path, 'original'),
    trailerTime: '2:30',
    year: (tmdbMedia.release_date || tmdbMedia.first_air_date || '2024').split('-')[0],
    seasons: tmdbMedia.number_of_seasons,
    episodes: tmdbMedia.number_of_episodes,
  };
};

const mediaCache = new Map<string, Media>();

export const getTrendingMedia = async (type: 'movie' | 'tv' | 'all' = 'all'): Promise<Media[]> => {
  const data = await fetchTMDB(`/trending/${type}/week`);
  if (!data) return [];

  const mediaPromises = data.results.slice(0, 15).map((item: any) =>
    getMediaDetails(item.id, item.media_type || (type === 'all' ? 'movie' : type))
  );
  return Promise.all(mediaPromises);
};

export const getMediaDetails = async (id: number, type: 'movie' | 'tv'): Promise<Media> => {
  const cacheKey = `${type}_${id}`;
  if (mediaCache.has(cacheKey)) {
    return mediaCache.get(cacheKey)!;
  }
  const data = await fetchTMDB(`/${type}/${id}`, {
    append_to_response: type === 'movie' ? 'credits,release_dates' : 'credits,content_ratings',
  });
  const media = mapTMDBMediaToMedia(data, type);
  mediaCache.set(cacheKey, media);
  return media;
};

export const searchMedia = async (query: string, page: number = 1): Promise<{ results: Media[]; totalPages: number }> => {
  const data = await fetchTMDB('/search/multi', { query, page: page.toString() });
  if (!data) return { results: [], totalPages: 0 };

  const results = await Promise.all(
    data.results
      .filter((item: any) => item.media_type === 'movie' || item.media_type === 'tv')
      .map(async (item: any) => getMediaDetails(item.id, item.media_type))
  );

  return {
    results,
    totalPages: data.total_pages,
  };
};

export const getDiscoverMedia = async (type: 'movie' | 'tv' = 'movie', page: number = 1, genreId?: string): Promise<{ results: Media[]; totalPages: number }> => {
  const params: Record<string, string> = {
    page: page.toString(),
    sort_by: 'popularity.desc'
  };
  if (genreId) {
    params.with_genres = genreId;
  }

  const data = await fetchTMDB(`/discover/${type}`, params);
  if (!data) return { results: [], totalPages: 0 };

  const results = await Promise.all(
    data.results.map(async (item: any) => getMediaDetails(item.id, type))
  );

  return {
    results,
    totalPages: data.total_pages,
  };
};

export const getGenres = async (type: 'movie' | 'tv' = 'movie'): Promise<{ id: number; name: string }[]> => {
  const data = await fetchTMDB(`/genre/${type}/list`);
  return data?.genres || [];
};

export const getSimilarMedia = async (id: number, type: 'movie' | 'tv'): Promise<Media[]> => {
  const data = await fetchTMDB(`/${type}/${id}/similar`);
  if (!data) return [];
  const results = await Promise.all(
    data.results.slice(0, 10).map(async (item: any) => getMediaDetails(item.id, type))
  );
  return results;
};

export const getRecommendations = async (id: number, type: 'movie' | 'tv'): Promise<Media[]> => {
  const data = await fetchTMDB(`/${type}/${id}/recommendations`);
  if (!data) return [];
  const results = await Promise.all(
    data.results.slice(0, 10).map(async (item: any) => getMediaDetails(item.id, type))
  );
  return results;
};

export const getRandomHighRatedMedia = async (): Promise<Media> => {
  const type = Math.random() > 0.5 ? 'movie' : 'tv';
  const page = Math.floor(Math.random() * 5) + 1;
  const data = await fetchTMDB(`/${type}/top_rated`, { page: page.toString() });
  if (!data) throw new Error('Failed to fetch top rated media');
  const randomIndex = Math.floor(Math.random() * data.results.length);
  return getMediaDetails(data.results[randomIndex].id, type);
};

export interface Person {
  id: number;
  name: string;
  biography: string;
  profilePath: string;
  knownFor: string;
  birthday: string;
  placeOfBirth: string;
  credits: Media[];
}

export const getTVShowSeasonDetails = async (tmdbId: number, seasonNumber: number) => {
  const data = await fetchTMDB(`/tv/${tmdbId}/season/${seasonNumber}`);
  if (!data) return null;

  // Map episodes to a more usable format if needed
  return data;
};

export const getPersonDetails = async (id: number): Promise<Person> => {
  const [details, credits] = await Promise.all([
    fetchTMDB(`/person/${id}`),
    fetchTMDB(`/person/${id}/combined_credits`)
  ]);

  const mappedCredits = await Promise.all(
    credits.cast
      .sort((a: any, b: any) => b.popularity - a.popularity)
      .slice(0, 10)
      .map(async (item: any) => {
        try {
          return await getMediaDetails(item.id, item.media_type as 'movie' | 'tv');
        } catch (e) {
          return null;
        }
      })
  );

  return {
    id: details.id,
    name: details.name,
    biography: details.biography,
    profilePath: getImageUrl(details.profile_path, 'h632'),
    knownFor: details.known_for_department,
    birthday: details.birthday,
    placeOfBirth: details.place_of_birth,
    credits: mappedCredits.filter((c): c is Media => c !== null)
  };
};

export const getTVShowSeasons = async (tmdbId: number) => {
  const data = await fetchTMDB(`/tv/${tmdbId}`);
  return data?.seasons || [];
};

