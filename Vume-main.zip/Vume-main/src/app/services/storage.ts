import { Media } from './tmdb';

const STORAGE_KEYS = {
  HISTORY: 'vume_watch_history',
  WATCHLIST: 'vume_watchlist',
  COLLECTIONS: 'vume_collections',
  PROGRESS: 'vume_progress',
};

export interface Progress {
  currentTime: number;
  duration: number;
  lastUpdated: number;
  season?: number;
  episode?: number;
}

export interface Collection {
  id: string;
  name: string;
  items: Media[];
}

export const storage = {
  // Watch History
  getHistory: (): Media[] => {
    const data = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return data ? JSON.parse(data) : [];
  },
  addToHistory: (item: Media) => {
    const history = storage.getHistory();
    const filtered = history.filter((m) => m.tmdbId !== item.tmdbId);
    const updated = [item, ...filtered].slice(0, 20); // Keep last 20
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updated));
  },

  // Watchlist (Saved)
  getWatchlist: (): Media[] => {
    const data = localStorage.getItem(STORAGE_KEYS.WATCHLIST);
    return data ? JSON.parse(data) : [];
  },
  toggleWatchlist: (item: Media) => {
    const watchlist = storage.getWatchlist();
    const exists = watchlist.some((m) => m.tmdbId === item.tmdbId && m.type === item.type);
    let updated;
    if (exists) {
      updated = watchlist.filter((m) => !(m.tmdbId === item.tmdbId && m.type === item.type));
    } else {
      updated = [item, ...watchlist];
    }
    localStorage.setItem(STORAGE_KEYS.WATCHLIST, JSON.stringify(updated));
    return !exists;
  },
  isInWatchlist: (tmdbId: number, type: 'movie' | 'tv'): boolean => {
    return storage.getWatchlist().some((m) => m.tmdbId === tmdbId && m.type === type);
  },

  // Collections
  getCollections: (): Collection[] => {
    const data = localStorage.getItem(STORAGE_KEYS.COLLECTIONS);
    return data ? JSON.parse(data) : [];
  },
  createCollection: (name: string) => {
    const collections = storage.getCollections();
    const newCollection: Collection = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      items: [],
    };
    localStorage.setItem(STORAGE_KEYS.COLLECTIONS, JSON.stringify([...collections, newCollection]));
    return newCollection;
  },
  addToCollection: (collectionId: string, item: Media) => {
    const collections = storage.getCollections();
    const updated = collections.map((col) => {
      if (col.id === collectionId) {
        const exists = col.items.some((m) => m.tmdbId === item.tmdbId && m.type === item.type);
        if (!exists) {
          return { ...col, items: [item, ...col.items] };
        }
      }
      return col;
    });
    localStorage.setItem(STORAGE_KEYS.COLLECTIONS, JSON.stringify(updated));
  },

  // Progress Tracking
  saveProgress: (tmdbId: number, type: 'movie' | 'tv', currentTime: number, duration: number, season?: number, episode?: number) => {
    const progressMap = storage.getAllProgress();
    const key = `${type}_${tmdbId}`;
    progressMap[key] = {
      currentTime,
      duration,
      lastUpdated: Date.now(),
      season,
      episode
    };
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progressMap));
  },
  getProgress: (tmdbId: number, type: 'movie' | 'tv'): Progress | null => {
    const progressMap = storage.getAllProgress();
    return progressMap[`${type}_${tmdbId}`] || null;
  },
  getAllProgress: (): Record<string, Progress> => {
    const data = localStorage.getItem(STORAGE_KEYS.PROGRESS);
    return data ? JSON.parse(data) : {};
  },

  // Vidfast Progress (deprecated in favor of general Progress)
  saveVidfastProgress: (key: string, data: any) => {
    localStorage.setItem(`vidfast_progress_${key}`, JSON.stringify(data));
    // Also save to our new progress system
    if (data.progress) {
      const [type, id] = [key[0] === 'm' ? 'movie' : 'tv', parseInt(key.slice(1))];
      storage.saveProgress(id, type as any, data.progress.watched, data.progress.duration);
    }
  },

  clearHistory: () => {
    localStorage.removeItem(STORAGE_KEYS.HISTORY);
    localStorage.removeItem(STORAGE_KEYS.PROGRESS);
  },

  clearAllData: () => {
    Object.values(STORAGE_KEYS).forEach(key => localStorage.removeItem(key));
    localStorage.clear(); // Complete wipe
  },

  deleteCollection: (id: string) => {
    const collections = storage.getCollections();
    const updated = collections.filter(c => c.id !== id);
    localStorage.setItem(STORAGE_KEYS.COLLECTIONS, JSON.stringify(updated));
  },

  removeFromCollection: (collectionId: string, tmdbId: number, type: string) => {
    const collections = storage.getCollections();
    const updated = collections.map(col => {
      if (col.id === collectionId) {
        return { ...col, items: col.items.filter(m => m.tmdbId !== tmdbId || m.type !== type) };
      }
      return col;
    });
    localStorage.setItem(STORAGE_KEYS.COLLECTIONS, JSON.stringify(updated));
  }
};

