import { useState, useEffect, useCallback, useRef } from 'react';
import { Search, Plus, Clock, MessageCircle, Heart, Bookmark, Play, Loader2, X, ChevronRight, Star, Menu, RotateCcw } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { getTrendingMedia, getRandomHighRatedMedia, getRecommendations, Media, getSimilarMedia, getTVShowSeasons, getPersonDetails, getTVShowSeasonDetails } from './services/tmdb';
import { storage } from './services/storage';
import Discover from './components/Discover';
import { Collections } from './components/Collections';
import { cn } from './components/ui/utils';
import { Player } from './components/Player';
// @ts-ignore
import logo from '../styles/logo.png';

export default function App() {
    const [view, setView] = useState<'home' | 'discover' | 'collections' | 'details' | 'person'>('home');
    const [selectedPerson, setSelectedPerson] = useState<any>(null);
    const [trending, setTrending] = useState<Media[]>([]);
    const [trendingMovies, setTrendingMovies] = useState<Media[]>([]);
    const [trendingTV, setTrendingTV] = useState<Media[]>([]);
    const [history, setHistory] = useState<Media[]>([]);
    const [recommendations, setRecommendations] = useState<Media[]>([]);
    const [watchlist, setWatchlist] = useState<Media[]>([]);
    const [selectedMedia, setSelectedMedia] = useState<Media | null>(null);
    const [playingMedia, setPlayingMedia] = useState<Media | null>(null);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [showMobileMenu, setShowMobileMenu] = useState(false);
    const [similarMedia, setSimilarMedia] = useState<Media[]>([]);
    const [selectedSeason, setSelectedSeason] = useState<any>(null);
    const [selectedEpisode, setSelectedEpisode] = useState<any>(null);
    const [seasons, setSeasons] = useState<any[]>([]);
    const [selectedSeasonDetails, setSelectedSeasonDetails] = useState<any>(null);
    const [isCreatingCollection, setIsCreatingCollection] = useState(false);
    const [newCollectionName, setNewCollectionName] = useState('');
    const [trendingIndex, setTrendingIndex] = useState(0);
    const trendingRef = useRef<HTMLDivElement>(null);
    const [accentColor, setAccentColor] = useState('#d95f47');

    const ACCENT_COLORS = ['#d95f47', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#6366f1', '#f43f5e', '#14b8a6'];

    const updateAccentFromImage = async (imageUrl: string) => {
        try {
            const img = new Image();
            img.crossOrigin = "Anonymous";

            await new Promise((resolve, reject) => {
                img.onload = resolve;
                img.onerror = reject;
                // Prevent CORS cache errors by appending a random timestamp or query param
                img.src = imageUrl + (imageUrl.includes('?') ? '&' : '?') + 'cors-bypass=' + Date.now();
            });

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            if (!ctx) return;

            canvas.width = 50;
            canvas.height = 50;
            ctx.drawImage(img, 0, 0, 50, 50);

            const imageData = ctx.getImageData(0, 0, 50, 50).data;
            const colorCounts: Record<string, number> = {};
            let maxCount = 0;
            let dominantColor = ACCENT_COLORS[0];

            const rgbToHsl = (r: number, g: number, b: number) => {
                r /= 255; g /= 255; b /= 255;
                const max = Math.max(r, g, b), min = Math.min(r, g, b);
                let h = 0, s = 0, l = (max + min) / 2;
                if (max !== min) {
                    const d = max - min;
                    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
                    switch (max) {
                        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                        case g: h = (b - r) / d + 2; break;
                        case b: h = (r - g) / d + 4; break;
                    }
                    h /= 6;
                }
                return { h: h * 360, s: s * 100, l: l * 100 };
            };

            for (let i = 0; i < imageData.length; i += 4) {
                const r = imageData[i], g = imageData[i + 1], b = imageData[i + 2], a = imageData[i + 3];
                if (a < 128) continue;

                const { h, s, l } = rgbToHsl(r, g, b);

                // Filter out grey/muted colors
                if (s < 15) continue;

                // Force into a "dark shade"
                // We want a rich, dark color: Lightness between 25% and 40%
                const darkL = Math.max(25, Math.min(40, l));
                // Keep saturation punchy (at least 50%)
                const vibrantS = Math.max(s, 50);

                const key = `${Math.round(h / 5) * 5},${Math.round(vibrantS / 10) * 10},${Math.round(darkL / 5) * 5}`;
                colorCounts[key] = (colorCounts[key] || 0) + 1;

                if (colorCounts[key] > maxCount) {
                    maxCount = colorCounts[key];
                    dominantColor = `hsl(${Math.round(h)}, ${Math.round(vibrantS)}%, ${Math.round(darkL)}%)`;
                }
            }

            setAccentColor(dominantColor);
        } catch (error) {
            console.warn('Color extraction failed:', error);
        }
    };

    const fetchHomeData = useCallback(async () => {
        setLoading(true);
        try {
            const [allTrending, movies, tv] = await Promise.all([
                getTrendingMedia('all'),
                getTrendingMedia('movie'),
                getTrendingMedia('tv')
            ]);

            setTrending(allTrending);
            setTrendingMovies(movies);
            setTrendingTV(tv);

            const savedHistory = storage.getHistory();
            setHistory(savedHistory);

            const savedWatchlist = storage.getWatchlist();
            setWatchlist(savedWatchlist);

            if (allTrending.length > 0) {
                const recs = await getRecommendations(allTrending[0].tmdbId, allTrending[0].type);
                setRecommendations(recs);
                if (!selectedMedia) setSelectedMedia(allTrending[0]);
            }
        } catch (error) {
            console.error('Failed to fetch home data:', error);
        } finally {
            setLoading(false);
        }
    }, [selectedMedia]);

    useEffect(() => {
        fetchHomeData();
    }, [fetchHomeData]);

    // Auto-scroll trending carousel & Featured Hero
    useEffect(() => {
        if (trending.length === 0 || view !== 'home') return;

        const interval = setInterval(() => {
            const nextIndex = (trendingIndex + 1) % 10;
            const nextMedia = trending[nextIndex];
            setTrendingIndex(nextIndex);
            setSelectedMedia(nextMedia);

            // Update accent color from poster image for the best matching shade
            updateAccentFromImage(nextMedia.posterImage);
        }, 5000); // 5 second next carousel rule

        return () => clearInterval(interval);
    }, [trending, trendingIndex, view]);

    useEffect(() => {
        if (trendingRef.current && trendingIndex >= 0 && trending.length > 0) {
            const container = trendingRef.current;
            const card = container.children[trendingIndex] as HTMLElement;
            if (card) {
                const scrollLeft = card.offsetLeft - container.offsetLeft - (container.offsetWidth - card.offsetWidth) / 2;
                container.scrollTo({
                    left: scrollLeft,
                    behavior: 'smooth'
                });
            }
        }
    }, [trendingIndex, trending]);

    useEffect(() => {
        const handlePopState = (e: PopStateEvent) => {
            if (playingMedia) {
                setPlayingMedia(null);
            } else if (view !== 'home') {
                setView('home');
            }
        };

        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape' || e.key === 'Backspace') {
                if (playingMedia) {
                    e.preventDefault();
                    setPlayingMedia(null);
                } else if (view !== 'home') {
                    e.preventDefault();
                    setView('home');
                }
            }
        };

        window.addEventListener('popstate', handlePopState);
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('popstate', handlePopState);
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [playingMedia, view]);

    const handleMediaSelect = async (media: Media) => {
        setSelectedMedia(media);
        setSelectedSeason(null);
        setSelectedEpisode(null);
        setSelectedSeasonDetails(null);
        setView('details');
        window.scrollTo({ top: 0, behavior: 'smooth' });

        // Set dynamic accent color from poster
        updateAccentFromImage(media.posterImage);

        // Fetch similar media and seasons for TV shows
        try {
            const similar = await getSimilarMedia(media.tmdbId, media.type);
            setSimilarMedia(similar);

            if (media.type === 'tv') {
                const data = await getTVShowSeasons(media.tmdbId);
                setSeasons(data);

                const progress = storage.getProgress(media.tmdbId, 'tv');
                // Auto-select season: previously watched or Season 1 (default)
                let seasonToSelect = progress?.season;
                if (!seasonToSelect) {
                    const firstSeason = data.find((s: any) => s.season_number === 1) || data[0];
                    seasonToSelect = firstSeason?.season_number || 1;
                }
                fetchSeasonDetails(seasonToSelect as number, media.tmdbId);
            }
        } catch (error) {
            console.error('Failed to fetch media extras:', error);
        }
    };

    const handlePersonSelect = async (personId: number) => {
        setLoading(true);
        try {
            const data = await getPersonDetails(personId);
            setSelectedPerson(data);
            setView('person');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (error) {
            console.error('Failed to fetch person details:', error);
        } finally {
            setLoading(false);
        }
    };

    const handlePlay = (media: Media) => {
        storage.addToHistory(media);
        setHistory(storage.getHistory());
        setPlayingMedia(media);
    };

    const handleEpisodeSelect = (season: number, episode: number) => {
        if (!playingMedia) return;
        setPlayingMedia({
            ...playingMedia,
            currentSeason: season,
            currentEpisode: episode
        });
    };

    const handleToggleWatchlist = (media: Media) => {
        storage.toggleWatchlist(media);
        setWatchlist(storage.getWatchlist());
    };

    const handleFeelingLucky = async () => {
        setLoading(true);
        try {
            const randomMedia = await getRandomHighRatedMedia();
            handleMediaSelect(randomMedia);
        } catch (error) {
            console.error('Lucky error:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleClearAllData = () => {
        if (confirm('Are you sure you want to clear all your watch history, watchlist, and collections? This cannot be undone.')) {
            storage.clearAllData();
            window.location.reload();
        }
    };

    const handleClearHistory = () => {
        if (confirm('Clear all watch history and progress?')) {
            storage.clearHistory();
            window.location.reload();
        }
    };

    const fetchSeasonDetails = async (seasonNumber: number, mediaId?: number) => {
        const id = mediaId || selectedMedia?.tmdbId;
        if (!id) return;

        setSelectedSeason(seasonNumber); // Set immediately for UI feedback
        try {
            const data = await getTVShowSeasonDetails(id, seasonNumber);
            setSelectedSeasonDetails(data);
        } catch (error) {
            console.error('Failed to fetch season details:', error);
        }
    };

    const handleCreateCollection = () => {
        if (!newCollectionName.trim()) return;
        storage.createCollection(newCollectionName);
        setIsCreatingCollection(false);
        setNewCollectionName('');
        setView('collections');
    };

    const renderPersonPage = () => {
        if (!selectedPerson) return null;
        return (
            <div className="space-y-12 animate-in fade-in duration-700">
                <div className="flex flex-col md:flex-row gap-12 items-start">
                    <div className="w-full md:w-80 shrink-0">
                        <div className="aspect-[2/3] rounded-3xl overflow-hidden shadow-2xl grainy border border-white/10">
                            <ImageWithFallback src={selectedPerson.profilePath} className="w-full h-full object-cover" />
                        </div>
                    </div>
                    <div className="flex-1 space-y-6">
                        <h1 className="text-6xl font-black tracking-tighter">{selectedPerson.name}</h1>
                        <div className="flex flex-wrap gap-4 text-sm font-bold uppercase tracking-widest text-[var(--accent-color)]">
                            {selectedPerson.birthday && <span>Born: {selectedPerson.birthday}</span>}
                            {selectedPerson.placeOfBirth && <span>From: {selectedPerson.placeOfBirth}</span>}
                            <span>Dept: {selectedPerson.knownFor}</span>
                        </div>
                        <p className="text-xl text-white/70 leading-relaxed font-light">{selectedPerson.biography || "No biography available."}</p>
                    </div>
                </div>

                <section>
                    <h2 className="text-3xl font-bold mb-8 uppercase tracking-widest">Known For</h2>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                        {selectedPerson.credits.map((item: Media) => (
                            <MediaCard key={`${item.type}_${item.tmdbId}`} media={item} onClick={() => handleMediaSelect(item)} onPlay={() => handlePlay(item)} />
                        ))}
                    </div>
                </section>
            </div>
        );
    };

    const renderTVShowExtras = (media: Media) => {
        if (media.type !== 'tv') return null;

        return (
            <div className="mt-24 space-y-12">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <h2 className="text-4xl font-bold tracking-tight">Seasons & Episodes</h2>
                    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
                        {seasons.map((s: any) => (
                            <button
                                key={s.season_number}
                                onClick={() => fetchSeasonDetails(s.season_number)}
                                className={cn(
                                    "px-6 py-2 rounded-full text-[10px] font-black tracking-widest transition-all border shrink-0",
                                    selectedSeason === s.season_number ? "bg-[var(--accent-color)] border-[var(--accent-color)] text-white" : "bg-transparent border-white/10 text-gray-500 hover:text-white"
                                )}
                            >
                                SEASON {s.season_number}
                            </button>
                        ))}
                    </div>
                </div>

                {selectedSeasonDetails ? (
                    <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-500">
                        {selectedSeasonDetails.episodes.map((ep: any) => {
                            const prog = storage.getProgress(media.tmdbId, 'tv');
                            const isCurrentEp = prog?.season === ep.season_number && prog?.episode === ep.episode_number;

                            return (
                                <div
                                    key={ep.id}
                                    onClick={() => {
                                        const epMedia = {
                                            ...media,
                                            title: `${media.title} - S${ep.season_number}E${ep.episode_number}`,
                                            currentSeason: ep.season_number,
                                            currentEpisode: ep.episode_number
                                        };
                                        handlePlay(epMedia);
                                    }}
                                    className={cn(
                                        "group flex items-center gap-6 p-4 rounded-[32px] cursor-pointer transition-all duration-300 grainy",
                                        isCurrentEp ? "bg-[var(--accent-color)]/10 border border-[var(--accent-color)]/30" : "bg-[#2a2420] border border-white/5 hover:border-white/20"
                                    )}
                                >
                                    <div className="relative w-48 aspect-video rounded-2xl overflow-hidden shrink-0">
                                        <ImageWithFallback src={getImageUrl(ep.still_path, 'w500')} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <Play className="w-8 h-8 fill-white text-white ml-1" />
                                        </div>
                                    </div>
                                    <div className="flex-1 min-w-0 pr-6">
                                        <div className="flex items-center gap-3 mb-1">
                                            <span className="text-[10px] font-black text-[var(--accent-color)] uppercase tracking-[0.2em]">EP {ep.episode_number}</span>
                                            {isCurrentEp && <span className="bg-[var(--accent-color)] text-white text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest">Watching</span>}
                                        </div>
                                        <h3 className="font-bold text-lg tracking-tight truncate group-hover:text-[var(--accent-color)] transition-colors">{ep.name}</h3>
                                        <p className="text-sm text-white/50 leading-relaxed font-light line-clamp-1 mt-1">{ep.overview || "No description available."}</p>
                                    </div>
                                    <div className="hidden md:flex flex-col items-end gap-2 shrink-0 pr-4">
                                        <div className="flex items-center gap-1.5 bg-black/40 px-3 py-1.5 rounded-xl border border-white/5">
                                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                                            <span className="text-xs font-black">{ep.vote_average.toFixed(1)}</span>
                                        </div>
                                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{ep.runtime || 45} MIN</span>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
                        {[1, 2, 3].map((n) => (
                            <div key={n} className="flex items-center gap-6 p-4 rounded-[32px] bg-[#2a2420]/50 border border-white/5 animate-pulse">
                                <div className="w-48 aspect-video rounded-2xl bg-white/5 shrink-0" />
                                <div className="flex-1 space-y-3">
                                    <div className="h-4 w-24 bg-white/10 rounded-full" />
                                    <div className="h-6 w-48 bg-white/10 rounded-full" />
                                    <div className="h-4 w-full bg-white/5 rounded-full" />
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        );
    };

    const getImageUrl = (path: string | null, size: string = 'w500') => {
        if (!path) return 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=2070&auto=format&fit=crop';
        return `https://image.tmdb.org/t/p/${size}${path}`;
    };

    const renderBentoBox = (media: Media) => {
        const progress = storage.getProgress(media.tmdbId, media.type);
        const hasStarted = progress && progress.currentTime > 0;

        return (
            <div className="flex flex-col gap-6 md:h-[calc(100vh-140px)] relative pb-8 md:pb-0">
                {/* Dynamic Background Blur */}
                <div
                    className="absolute inset-x-[-100px] inset-y-[-100px] opacity-20 blur-[100px] saturate-[200%] pointer-events-none"
                    style={{ backgroundImage: `url(${media.posterImage})`, backgroundSize: 'cover' }}
                />

                <div className="flex-1 grid grid-cols-2 md:grid-cols-12 gap-4 auto-rows-fr relative z-10">
                    <div className="col-span-2 md:col-span-3 row-span-1 md:row-span-4 relative rounded-3xl overflow-hidden bg-white/5 backdrop-blur-md flex flex-col items-center justify-center border border-white/10 p-6 grainy order-3 md:order-none">
                        <Clock className="w-8 h-8 md:w-12 md:h-12 text-[var(--accent-color)] mb-2 md:mb-4" />
                        <span className="text-4xl md:text-6xl mb-1 md:mb-2 font-light">
                            {media.type === 'movie' ? media.duration : media.episodes || 'N/A'}
                        </span>
                        <span className="text-[10px] md:text-xs text-gray-400 uppercase tracking-widest">
                            {media.type === 'movie' ? 'Duration' : 'Episodes'}
                        </span>
                    </div>

                    {/* Rating Tile */}
                    <div className="col-span-1 md:col-span-2 md:col-start-4 row-span-1 md:row-span-2 md:row-start-1 rounded-3xl bg-[#f5f1ed] flex flex-col items-center justify-center p-4 grainy order-4 md:order-none">
                        <span className="text-4xl md:text-6xl text-[var(--accent-color)] font-light">{media.rating}</span>
                        <span className="text-[10px] md:text-xs text-gray-600 mt-1 uppercase tracking-widest">Rating</span>
                    </div>

                    {/* Age Rating Tile */}
                    <div className="col-span-1 md:col-span-2 md:col-start-4 row-span-1 md:row-span-2 md:row-start-3 rounded-3xl bg-white/10 backdrop-blur-md flex items-center justify-center p-4 border border-white/10 grainy order-5 md:order-none">
                        <span className="text-3xl md:text-5xl text-white border-2 md:border-4 border-white px-3 py-1 md:px-4 md:py-2 rounded-xl font-black">{media.ageRating}</span>
                    </div>

                    {/* Backdrop Tile */}
                    <div className="col-span-2 md:col-span-7 md:col-start-6 row-span-2 md:row-span-12 md:row-start-1 relative rounded-3xl overflow-hidden group min-h-[300px] md:min-h-0 grainy order-1 md:order-none">
                        <ImageWithFallback
                            src={media.backdropImage}
                            alt={media.title}
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

                        <div className="absolute bottom-6 left-6 md:bottom-8 md:left-8 flex flex-col gap-4">
                            <div className="flex items-center gap-3">
                                <button
                                    onClick={() => handlePlay(media)}
                                    className="flex items-center gap-3 group/play bg-black/40 backdrop-blur-md p-2 pr-6 rounded-full hover:bg-black/60 transition-all border border-white/10"
                                >
                                    <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-[var(--accent-color)] flex items-center justify-center group-hover/play:scale-110 transition-all duration-1000">
                                        <Play className="w-5 h-5 md:w-6 md:h-6 fill-white text-white ml-1" />
                                    </div>
                                    <div className="text-left">
                                        <div className="text-base md:text-lg font-black uppercase tracking-tight">
                                            {hasStarted ? 'Resume' : 'Play'} {
                                                media.type === 'movie'
                                                    ? 'Movie'
                                                    : (progress?.season ? `S${progress.season} E${progress.episode}` : 'S1 E1')
                                            }
                                        </div>
                                        <div className="text-[10px] md:text-xs text-white/60 tracking-wider">
                                            {hasStarted
                                                ? `${Math.round((progress.currentTime / progress.duration) * 100)}% watched`
                                                : `TMDB: ${media.tmdbId}`}
                                        </div>
                                    </div>
                                </button>

                                {hasStarted && (
                                    <button
                                        onClick={() => {
                                            storage.saveProgress(media.tmdbId, media.type, 0, progress.duration);
                                            handlePlay(media);
                                        }}
                                        className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white/10 backdrop-blur-md border border-white/10 flex items-center justify-center hover:bg-white/20 transition-all group"
                                        title="Start Over"
                                    >
                                        <RotateCcw className="w-5 h-5 md:w-6 md:h-6 text-white group-hover:rotate-[-45deg] transition-transform" />
                                    </button>
                                )}
                            </div>
                        </div>

                        <div className="absolute top-4 right-4 flex flex-col gap-2 md:gap-3">
                            <button className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-center hover:bg-black/60 transition-all">
                                <MessageCircle className="w-4 h-4 md:w-5 md:h-5" />
                            </button>
                            <button
                                onClick={() => handleToggleWatchlist(media)}
                                className={cn(
                                    "w-10 h-10 md:w-12 md:h-12 rounded-full backdrop-blur-md border border-white/10 flex items-center justify-center transition-all duration-1000",
                                    storage.isInWatchlist(media.tmdbId, media.type) ? "bg-[var(--accent-color)] border-[var(--accent-color)]" : "bg-black/40 hover:bg-black/60"
                                )}
                            >
                                <Heart className={cn("w-4 h-4 md:w-5 md:h-5", storage.isInWatchlist(media.tmdbId, media.type) && "fill-white")} />
                            </button>
                            <button className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-center hover:bg-black/60 transition-all">
                                <Bookmark className="w-4 h-4 md:w-5 md:h-5" />
                            </button>
                        </div>
                    </div>

                    {/* About Tile */}
                    <div className="col-span-2 md:col-span-5 md:col-start-1 row-span-2 md:row-span-8 md:row-start-5 rounded-[40px] bg-[var(--accent-color)] p-6 md:p-8 overflow-hidden relative border border-white/20 shadow-2xl shadow-[var(--accent-color)]/40 grainy uppercase group/about transition-all duration-1000 order-2 md:order-none">
                        <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent pointer-events-none" />
                        <p className="relative z-10 text-[10px] md:text-xs text-white/70 mb-2 md:mb-4 tracking-[0.4em] uppercase font-black">About {media.type === 'movie' ? 'Film' : 'Show'}</p>
                        <h1 className="relative z-10 text-4xl md:text-5xl lg:text-6xl mb-4 md:mb-6 font-black tracking-tighter leading-none group-hover:scale-[1.02] transition-transform duration-500">{media.title}</h1>
                        <p className="relative z-10 text-sm md:text-base lg:text-lg text-white/90 mb-6 md:mb-8 leading-relaxed line-clamp-2 md:line-clamp-4 font-light">{media.description}</p>

                        <div className="hidden lg:block mb-6">
                            <p className="text-[10px] text-white/70 mb-2 tracking-[0.2em] uppercase font-bold">Starring</p>
                            <div className="flex flex-wrap gap-x-3 gap-y-1">
                                {media.cast.map((actor: { id: number; name: string }, idx: number) => (
                                    <button
                                        key={idx}
                                        onClick={() => handlePersonSelect(actor.id)}
                                        className="text-sm border-b border-white/30 pb-0.5 hover:border-[var(--accent-color)] transition-all hover:text-[var(--accent-color)] cursor-pointer"
                                    >
                                        {actor.name}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="flex items-center gap-3 md:gap-4 mt-auto">
                            <div className="w-16 h-16 md:w-24 md:h-24 rounded-3xl border border-white/20 bg-white/5 backdrop-blur-sm flex flex-col items-center justify-center shrink-0">
                                <span className="text-xl md:text-2xl font-light">{media.popularity}</span>
                                <span className="text-[8px] md:text-[9px] mt-0.5 uppercase tracking-widest text-white/60">Popularity</span>
                            </div>
                            <button
                                onClick={() => handlePersonSelect(media.director.id)}
                                className="flex-1 rounded-3xl border border-white/20 bg-white/5 backdrop-blur-sm p-4 md:p-6 flex items-center gap-3 overflow-hidden text-left hover:bg-white/10 transition-colors group/dir"
                            >
                                <ImageWithFallback src={media.directorImage} className="w-10 h-10 md:w-16 md:h-16 rounded-full object-cover shrink-0 border border-white/20 group-hover/dir:scale-110 transition-transform" />
                                <div className="overflow-hidden">
                                    <p className="text-[8px] md:text-[10px] text-white/60 tracking-widest mb-0.5 md:mb-1 uppercase font-bold">{media.type === 'movie' ? 'Director' : 'Executive Producer'}</p>
                                    <p className="text-sm md:text-lg font-black truncate uppercase tracking-tighter hover:text-white transition-colors">{media.director.name}</p>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>

                {/* TV Show Seasons/Episodes Section & Recommendations */}
                <div className="flex flex-col gap-16">
                    <div className="flex-1">
                        {media.type === 'tv' && view === 'details' && renderTVShowExtras(media)}
                    </div>

                    {/* More Like This (Details View) */}
                    {view === 'details' && similarMedia.length > 0 && (
                        <div className="w-full flex flex-col gap-8 relative z-10 shrink-0">
                            <div className="bg-white/5 backdrop-blur-xl border border-white/5 rounded-[40px] p-8 md:p-12 grainy h-full flex flex-col">
                                <h2 className="text-3xl font-black uppercase tracking-widest mb-10 flex items-center gap-3">
                                    <Plus className="w-8 h-8 text-[var(--accent-color)]" /> More Like This
                                </h2>
                                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 flex-1">
                                    {similarMedia.slice(0, 6).map((item) => (
                                        <button
                                            key={`${item.type}_${item.tmdbId}`}
                                            onClick={() => handleMediaSelect(item)}
                                            className="group relative rounded-3xl overflow-hidden aspect-[2/3] border border-white/5 hover:border-[var(--accent-color)]/50 transition-all shrink-0"
                                        >
                                            <ImageWithFallback src={item.posterImage} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                                            <div className="absolute bottom-4 left-4 right-4 text-left">
                                                <p className="text-[10px] font-black uppercase tracking-widest truncate">{item.title}</p>
                                                <p className="text-[8px] text-white/50 uppercase tracking-widest mt-1">{item.year}</p>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-[#1a1410] text-white transition-colors duration-1000 overflow-x-hidden w-full relative" style={{ '--accent-color': accentColor } as any}>
            {/* Navigation Bar */}
            <nav className="fixed top-0 left-0 right-0 z-50 bg-[#1a1410]/95 backdrop-blur-md px-4 md:px-8 py-4 md:py-6 flex items-center justify-between border-b border-[#3a3430]">
                <div className="flex items-center gap-4 md:gap-8">
                    <button
                        onClick={() => { setView('home'); setSearchQuery(''); setShowMobileMenu(false); }}
                        className="flex items-center hover:opacity-80 transition-opacity"
                    >
                        <img src={logo} alt="VUME" className="h-6 md:h-8 w-auto object-contain" />
                    </button>

                    <div className="hidden lg:flex items-center gap-6">
                        <button
                            onClick={() => setView('collections')}
                            className={cn(
                                "px-4 py-2 rounded-lg transition-all",
                                view === 'collections' ? "bg-[var(--accent-color)] text-white" : "bg-[#3a3430] text-gray-400 hover:text-white"
                            )}
                        >
                            My collections
                        </button>
                        <button
                            onClick={() => { setView('discover'); setSearchQuery(''); }}
                            className={cn(
                                "transition-colors",
                                view === 'discover' ? "text-white" : "text-gray-400 hover:text-white"
                            )}
                        >
                            Discover
                        </button>
                        <button
                            onClick={handleFeelingLucky}
                            className="text-gray-400 hover:text-white transition-colors"
                        >
                            I am feeling lucky
                        </button>
                    </div>
                </div>

                {/* Desktop: search + create */}
                <div className="hidden lg:flex items-center gap-4">
                    <form
                        onSubmit={(e) => { e.preventDefault(); setView('discover'); }}
                        className="relative"
                    >
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="bg-[#3a3430]/50 backdrop-blur-md text-white rounded-full pl-9 pr-4 py-2 w-72 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] transition-all border border-white/10"
                        />
                    </form>
                    <button
                        onClick={() => setIsCreatingCollection(true)}
                        className="flex items-center gap-2 bg-[var(--accent-color)] hover:opacity-90 transition-opacity rounded-full px-4 py-2 text-sm shrink-0 shadow-lg shadow-[var(--accent-color)]/20"
                    >
                        <Plus className="w-4 h-4" />
                        <span>Create collection</span>
                    </button>
                </div>

                {/* Mobile: hamburger only */}
                <button
                    onClick={() => setShowMobileMenu(!showMobileMenu)}
                    className="lg:hidden p-2 text-gray-400 hover:text-white relative z-[70]"
                >
                    {showMobileMenu ? <X className="w-6 h-6 text-white" /> : <Menu className="w-6 h-6" />}
                </button>
            </nav>

            {/* Mobile Menu Overlay - Placed outside of nav to prevent flex disruption */}
            {showMobileMenu && (
                <div className="fixed inset-0 bg-[#0a0503] z-[65] lg:hidden flex flex-col p-6 pt-28 animate-in fade-in duration-300">
                    <form
                        onSubmit={(e) => { e.preventDefault(); setView('discover'); setShowMobileMenu(false); }}
                        className="relative mb-6 shrink-0"
                    >
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
                        <input
                            type="text"
                            placeholder="Search..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 py-4 text-lg text-white placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)]/50 transition-all font-bold"
                            autoFocus
                        />
                    </form>

                    <div className="space-y-2 md:space-y-4 overflow-y-auto no-scrollbar pb-8 flex-1">
                        <button
                            onClick={() => { setView('home'); setShowMobileMenu(false); }}
                            className={cn(
                                "w-full text-4xl md:text-5xl font-black uppercase tracking-tighter text-left py-3 md:py-4 transition-colors",
                                view === 'home' ? "text-[var(--accent-color)]" : "text-white/40"
                            )}
                        >
                            Home
                        </button>
                        <button
                            onClick={() => { setView('collections'); setShowMobileMenu(false); }}
                            className={cn(
                                "w-full text-4xl md:text-5xl font-black uppercase tracking-tighter text-left py-3 md:py-4 transition-colors",
                                view === 'collections' ? "text-[var(--accent-color)]" : "text-white/40"
                            )}
                        >
                            Collections
                        </button>
                        <button
                            onClick={() => { setView('discover'); setShowMobileMenu(false); }}
                            className={cn(
                                "w-full text-4xl md:text-5xl font-black uppercase tracking-tighter text-left py-3 md:py-4 transition-colors",
                                view === 'discover' ? "text-[var(--accent-color)]" : "text-white/40"
                            )}
                        >
                            Discover
                        </button>
                        <button
                            onClick={() => { handleFeelingLucky(); setShowMobileMenu(false); }}
                            className="w-full text-4xl md:text-5xl font-black uppercase tracking-tighter text-left py-3 md:py-4 text-white/40"
                        >
                            Random
                        </button>
                    </div>

                    <div className="mt-auto pb-6 shrink-0 pt-4">
                        <button
                            onClick={() => { setIsCreatingCollection(true); setShowMobileMenu(false); }}
                            className="w-full py-5 rounded-2xl bg-[var(--accent-color)] text-white font-black uppercase tracking-widest text-sm shadow-xl"
                        >
                            Create Collection
                        </button>
                    </div>
                </div>
            )}

            <main className="pt-20 md:pt-28 px-4 md:px-8 pb-12 bg-[#1a1410]">
                {loading && view === 'home' && trending.length === 0 ? (
                    <div className="flex items-center justify-center h-[calc(100vh-140px)]">
                        <Loader2 className="w-12 h-12 text-[var(--accent-color)] animate-spin" />
                    </div>
                ) : view === 'discover' ? (
                    <Discover
                        onMediaSelect={handleMediaSelect}
                        searchQuery={searchQuery}
                    />
                ) : view === 'collections' ? (
                    <Collections
                        onMediaSelect={handleMediaSelect}
                        onPlay={handlePlay}
                    />
                ) : view === 'person' ? (
                    renderPersonPage()
                ) : (
                    <div className="space-y-12 md:space-y-24">
                        {/* Selected Media Bento Box (Details or Featured) */}
                        {selectedMedia && (view === 'details' || view === 'home') && renderBentoBox(selectedMedia)}

                        {/* Home View Specific Content */}
                        {view === 'home' && (
                            <div className="space-y-16">
                                {/* Hero Trending Carousel */}
                                <section className="relative -mx-4 md:-mx-8 px-4 md:px-8 overflow-hidden">
                                    <div className="flex items-center justify-between mb-8">
                                        <h1 className="text-4xl md:text-6xl font-black tracking-tighter uppercase leading-none">Trending Now</h1>
                                        <button onClick={() => setView('discover')} className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-gray-500 hover:text-white transition-colors">
                                            View All <ChevronRight className="w-4 h-4" />
                                        </button>
                                    </div>
                                    <div
                                        ref={trendingRef}
                                        className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-8"
                                    >
                                        {trending.slice(0, 10).map((item: Media, index: number) => (
                                            <div
                                                key={`trending_${item.tmdbId}`}
                                                className={cn(
                                                    "relative min-w-[300px] md:min-w-[700px] aspect-video rounded-[40px] overflow-hidden snap-center cursor-pointer group grainy transition-all duration-1000",
                                                    trendingIndex === index ? "ring-2 ring-[var(--accent-color)] ring-offset-4 ring-offset-[#1a1410]" : "opacity-80 scale-95"
                                                )}
                                                onClick={() => {
                                                    setTrendingIndex(index);
                                                    handleMediaSelect(item);
                                                }}
                                            >
                                                <ImageWithFallback src={item.backdropImage} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                                                <div className="absolute bottom-8 left-8 right-8">
                                                    <div className="flex items-center gap-3 mb-4">
                                                        <span className="px-3 py-1 rounded-full bg-[var(--accent-color)] text-[10px] font-black uppercase tracking-widest text-white shadow-xl">Trending</span>
                                                        <span className="text-[10px] font-black uppercase tracking-widest text-white/60">Released {item.year}</span>
                                                    </div>
                                                    <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter mb-4 line-clamp-1 group-hover:text-[var(--accent-color)] transition-colors">{item.title}</h2>
                                                    <div className="flex items-center gap-6">
                                                        <div className="flex items-center gap-2">
                                                            <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                                                            <span className="font-black text-lg">{item.rating}</span>
                                                        </div>
                                                        <span className="text-sm font-light text-white/60 uppercase tracking-widest">{item.type === 'movie' ? 'Movie' : 'TV Show'}</span>
                                                    </div>
                                                </div>
                                                <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 flex items-center justify-center">
                                                        <Play className="w-6 h-6 fill-white text-white ml-1" />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </section>

                                {/* Continue Watching Section */}
                                {history.length > 0 && (
                                    <section>
                                        <div className="flex items-center justify-between mb-8">
                                            <h2 className="text-3xl font-black uppercase tracking-tighter">Continue Watching</h2>
                                            <button className="flex items-center gap-2 text-gray-500 hover:text-white transition-colors text-xs font-black uppercase tracking-widest">
                                                View all <ChevronRight className="w-4 h-4" />
                                            </button>
                                        </div>
                                        <div className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-4">
                                            {history.slice(0, 10).map((item: Media) => {
                                                const progress = storage.getProgress(item.tmdbId, item.type);
                                                const percent = progress ? (progress.currentTime / progress.duration) * 100 : 0;
                                                return (
                                                    <div key={`${item.type}_${item.tmdbId}`} className="min-w-[280px] md:min-w-[400px] snap-start group cursor-pointer" onClick={() => handleMediaSelect(item)}>
                                                        <div className="relative aspect-video rounded-[32px] overflow-hidden mb-4 grainy border border-white/5">
                                                            <ImageWithFallback src={item.backdropImage} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                                                            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                                                                <div className="w-14 h-14 rounded-full bg-[var(--accent-color)] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100 shadow-2xl">
                                                                    <Play className="w-6 h-6 fill-white text-white ml-1" />
                                                                </div>
                                                            </div>
                                                            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/10 overflow-hidden">
                                                                <div className="h-full bg-[var(--accent-color)] transition-all" style={{ width: `${percent}%` }} />
                                                            </div>
                                                        </div>
                                                        <div className="flex justify-between items-start gap-4">
                                                            <div>
                                                                <h3 className="font-black uppercase tracking-tight line-clamp-1 group-hover:text-[var(--accent-color)] transition-colors">{item.title}</h3>
                                                                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mt-1">{item.type === 'movie' ? item.duration : 'TV Series'}</p>
                                                            </div>
                                                            <span className="text-[10px] font-black text-[var(--accent-color)] uppercase tracking-widest">{Math.round(percent)}%</span>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </section>
                                )}

                                {/* Trending Movies */}
                                <section>
                                    <div className="flex items-center justify-between mb-8">
                                        <h2 className="text-3xl font-black uppercase tracking-tighter">Trending Movies</h2>
                                        <button onClick={() => { setView('discover'); setSearchQuery(''); }} className="flex items-center gap-2 text-gray-500 hover:text-white transition-colors text-xs font-black uppercase tracking-widest">
                                            Explore <ChevronRight className="w-4 h-4" />
                                        </button>
                                    </div>
                                    <div className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-4">
                                        {trendingMovies.slice(0, 15).map((item: Media) => (
                                            <div key={`${item.type}_${item.tmdbId}`} className="min-w-[200px] md:min-w-[240px] snap-start">
                                                <MediaCard media={item} onClick={() => handleMediaSelect(item)} onPlay={() => handlePlay(item)} />
                                            </div>
                                        ))}
                                    </div>
                                </section>

                                {/* Trending TV Shows */}
                                <section>
                                    <div className="flex items-center justify-between mb-8">
                                        <h2 className="text-3xl font-black uppercase tracking-tighter">Top TV Series</h2>
                                        <button onClick={() => { setView('discover'); setSearchQuery(''); }} className="flex items-center gap-2 text-gray-500 hover:text-white transition-colors text-xs font-black uppercase tracking-widest">
                                            Explore <ChevronRight className="w-4 h-4" />
                                        </button>
                                    </div>
                                    <div className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-4">
                                        {trendingTV.slice(0, 15).map((item: Media) => (
                                            <div key={`${item.type}_${item.tmdbId}`} className="min-w-[200px] md:min-w-[240px] snap-start">
                                                <MediaCard media={item} onClick={() => handleMediaSelect(item)} onPlay={() => handlePlay(item)} />
                                            </div>
                                        ))}
                                    </div>
                                </section>

                                {/* Recommendations */}
                                {recommendations.length > 0 && (
                                    <section>
                                        <div className="flex items-center justify-between mb-8">
                                            <h2 className="text-3xl font-black uppercase tracking-tighter">Your Recommendations</h2>
                                        </div>
                                        <div className="flex gap-6 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-4">
                                            {recommendations.slice(0, 15).map((item: Media) => (
                                                <div key={`${item.type}_${item.tmdbId}`} className="min-w-[200px] md:min-w-[240px] snap-start">
                                                    <MediaCard media={item} onClick={() => handleMediaSelect(item)} onPlay={() => handlePlay(item)} />
                                                </div>
                                            ))}
                                        </div>
                                    </section>
                                )}
                                {/* Transition to Discover */}
                                <div className="py-20 flex flex-col items-center justify-center border-t border-white/5 grainy rounded-[40px] bg-white/5">
                                    <p className="text-gray-500 mb-6 font-black uppercase tracking-widest text-[10px]">End of home screen. Keep exploring?</p>
                                    <button
                                        onClick={() => { setView('discover'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                                        className="px-12 py-5 rounded-3xl bg-[var(--accent-color)] text-white font-black uppercase tracking-widest hover:opacity-90 transition-all transform hover:scale-105 shadow-2xl shadow-[var(--accent-color)]/20 text-xs"
                                    >
                                        Go to Discover
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </main>

            {/* Player Modal Frame */}
            {(() => {
                if (!playingMedia) return null;
                const pm = playingMedia;
                return (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12 animate-in fade-in zoom-in duration-300">
                        {/* Backdrop with slight blur */}
                        <div
                            className="absolute inset-0 bg-black/90 backdrop-blur-sm cursor-pointer"
                            onClick={() => setPlayingMedia(null)}
                        />

                        {/* Close Button: Moved to Top Right of the Screen */}
                        <button
                            onClick={() => setPlayingMedia(null)}
                            className="absolute top-6 right-6 md:top-8 md:right-8 z-[110] p-3 md:p-4 bg-black/60 hover:bg-black/80 backdrop-blur-md rounded-full border border-white/20 text-white transition-all hover:scale-110 active:scale-95 group"
                            title="Close Player"
                        >
                            <X className="w-6 h-6 md:w-8 md:h-8 group-hover:rotate-90 transition-transform duration-300" />
                        </button>

                        <div className="relative w-full max-w-6xl aspect-video bg-black rounded-[32px] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.8)] border border-white/10">
                            <Player
                                movie={{
                                    id: pm.tmdbId,
                                    type: pm.type,
                                    title: pm.title,
                                    posterImage: pm.posterImage,
                                    backdropImage: pm.backdropImage,
                                    currentSeason: pm.currentSeason,
                                    currentEpisode: pm.currentEpisode
                                }}
                            />
                        </div>
                    </div>
                );
            })()}

            {/* Collection Creation Modal */}
            {
                isCreatingCollection && (
                    <div className="fixed inset-0 z-[110] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
                        <div className="w-full max-w-md bg-[#2a2420] rounded-[40px] p-10 border border-white/10 space-y-8 grainy">
                            <div className="space-y-2">
                                <h2 className="text-3xl font-black tracking-tighter">New Collection</h2>
                                <p className="text-gray-500 text-sm">Create a custom list of your favorite titles.</p>
                            </div>
                            <input
                                autoFocus
                                type="text"
                                placeholder="Collection name (e.g. Sci-Fi Favorites)"
                                value={newCollectionName}
                                onChange={(e) => setNewCollectionName(e.target.value)}
                                className="w-full bg-[#1a1410] border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-[var(--accent-color)] transition-all"
                            />
                            <div className="flex gap-4">
                                <button
                                    onClick={() => setIsCreatingCollection(false)}
                                    className="flex-1 px-6 py-4 rounded-2xl bg-white/5 hover:bg-white/10 font-bold transition-all"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={handleCreateCollection}
                                    className="flex-1 px-6 py-4 rounded-2xl bg-[var(--accent-color)] hover:opacity-90 font-bold transition-all shadow-lg shadow-[var(--accent-color)]/20"
                                >
                                    Create
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }
        </div >
    );
}

function MediaCard({ media, onClick, onPlay }: { media: Media, onClick: () => void, onPlay: () => void }) {
    const progress = storage.getProgress(media.tmdbId, media.type);
    const hasStarted = progress && progress.currentTime > 0;
    const percent = hasStarted ? (progress.currentTime / progress.duration) * 100 : 0;

    return (
        <div className="group cursor-pointer space-y-4" onClick={onClick}>
            <div className="relative aspect-[2/3] rounded-[40px] overflow-hidden grainy bg-white/5 border border-white/5 shadow-2xl shadow-black/40 transition-all duration-500 group-hover:shadow-[var(--accent-color)]/20 group-hover:-translate-y-2">
                <ImageWithFallback
                    src={media.posterImage}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />

                {/* Hover UI Overlay */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-4">
                    <div
                        onClick={(e) => { e.stopPropagation(); onPlay(); }}
                        className="w-16 h-16 rounded-full bg-[var(--accent-color)] flex items-center justify-center transform scale-90 group-hover:scale-100 transition-transform shadow-2xl shadow-[var(--accent-color)]/40"
                    >
                        <Play className="w-8 h-8 fill-white text-white ml-1" />
                    </div>
                    <button
                        onClick={(e) => { e.stopPropagation(); storage.toggleWatchlist(media); }}
                        className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-white/20 transition-all flex items-center gap-2"
                    >
                        <Bookmark className={cn("w-3.5 h-3.5", storage.isInWatchlist(media.tmdbId, media.type) && "fill-white")} />
                        {storage.isInWatchlist(media.tmdbId, media.type) ? 'Saved' : 'Save'}
                    </button>
                </div>

                {/* Rating Badge */}
                <div className="absolute top-3 right-3 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                    <span className="text-[10px] font-bold">{media.rating}</span>
                </div>

                {/* Progress Bar */}
                {hasStarted && (
                    <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/10 overflow-hidden">
                        <div
                            className="h-full bg-[var(--accent-color)] transition-all duration-300"
                            style={{ width: `${percent}%` }}
                        />
                    </div>
                )}
            </div>
            <div>
                <h3 className="font-bold text-sm lg:text-base leading-tight truncate group-hover:text-[var(--accent-color)] transition-colors">{media.title}</h3>
                <div className="flex items-center justify-between mt-1">
                    <p className="text-[10px] lg:text-xs text-gray-500 uppercase tracking-widest font-medium">
                        {media.type === 'movie' ? media.duration : 'TV Series'}
                    </p>
                    {hasStarted && (
                        <span className="text-[9px] text-[var(--accent-color)] font-bold uppercase tracking-tighter">
                            {Math.round(percent)}%
                        </span>
                    )}
                </div>
            </div>
        </div>
    );
}


